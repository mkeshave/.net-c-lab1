﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            int id1, salary1;
            string name1, add1, city1, department1;
            //Employee emp = new Employee();
            //emp.displaysalary(101, "msk", "pune", "ece", "abc", 909); //Task-1

            ////Task-2
            //Console.WriteLine("Enter id number");
            //int id = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("Enter Name");
            //string name = Console.ReadLine();

            //Console.WriteLine("Enter Address");
            //string add = Console.ReadLine();

            //Console.WriteLine("Enter City");
            //string city = Console.ReadLine();

            //Console.WriteLine("Enter Department");
            //string department = Console.ReadLine();

            //Console.WriteLine("Enter salary");
            //int salary = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("\n" + id + name + add + city + department + salary);

            //Task-3

            Employee[] objEmployee = new Employee[10];
            for (int i = 0; i < objEmployee.Length; i++)
            {
                objEmployee[i] = new Employee();
                Console.WriteLine("Enter id number");
                id1 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Name");
                name1 = Console.ReadLine();

                Console.WriteLine("Enter Address");
                add1 = Console.ReadLine();

                Console.WriteLine("Enter City");
                city1 = Console.ReadLine();

                Console.WriteLine("Enter Department");
                department1 = Console.ReadLine();

                Console.WriteLine("Enter salary");
                salary1 = Convert.ToInt32(Console.ReadLine());

                objEmployee[i].setEmpDetails(id1, name1, add1, city1, department1, salary1);

            }
            for (int index = 0; index < objEmployee.Length; index++)
            {

                objEmployee[index].display();
                //Console.WriteLine((index+1) +"Employee Name:"+" "+ objEmployee[index].employee_Name +" "+"emp sla:"+ objEmployee[index].salary);
            }

            Console.ReadLine();
        }
    }
}