﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Employee
    {
      public  int employeeId, salary;
       public string employee_Name, address, city, department;

        //Task-1

        public void displaysalary(int id,string name,string add,string city,string department,int salary)
        {
            Console.WriteLine("Salary :" + salary);
        }



        //Task-2

        public void setEmpDetails(int id, string empName, string add, string city, string depart, int salary)
        {
            employeeId = id;
            this.salary = salary;
            employee_Name = empName;
            address = add;
            this.city = city;
            department = depart;

        }

        //Task- 3
        public void display()
        {
            Console.WriteLine("Employee Name:"+ employee_Name + "Salary :" + salary);
        }
    }
}
