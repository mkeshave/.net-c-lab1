﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmeticOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, result;
            int b, choice;
            string value;
            double res, number1, number2;

            Console.WriteLine("Enter value wither int or double");
            value = Console.ReadLine();
            Operation objOperation = new Operation();

            if (value.Equals("int"))
            {
                Console.WriteLine("Enter two numbers");
                a = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter two numbers");
                b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter your choice 1 for addition and 2 for subtraction and 3 for multiplication and 4 for division and 5 for modulus");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        result = objOperation.Addition(a, b);
                        Console.WriteLine("Result is: " + result);
                        break;

                    case 2:
                        result = objOperation.Subtraction(a, b);
                        Console.WriteLine("Result is: " + result);
                        break;

                    case 3:
                        result = objOperation.Multiplication(a, b);
                        Console.WriteLine("Result is: " + result);
                        break;

                    case 4:
                        result = objOperation.Division(a, b);
                        Console.WriteLine("Result is: " + result);
                        break;

                    case 5:
                        result = objOperation.Modulus(a, b);
                        Console.WriteLine("Result is: " + result);
                        break;
                }
            }
            else
            {
                Console.WriteLine("Enter two numbers");
                number1 = Convert.ToDouble(Console.ReadLine());


                number2 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Enter your choice 1 for addition and 2 for subtraction and 3 for multiplication and 4 for division and 5 for modulus");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        res = objOperation.Addition(number1, number2);
                        Console.WriteLine("Result is: " + res);
                        break;

                    case 2:
                        res = objOperation.Subtraction(number1, number2);
                        Console.WriteLine("Result is: " + res);
                        break;

                    case 3:
                        res = objOperation.Multiplication(number1, number2);
                        Console.WriteLine("Result is: " + res);
                        break;

                    case 4:
                        res = objOperation.Division(number1, number2);
                        Console.WriteLine("Result is: " + res);
                        break;

                    case 5:
                        res = objOperation.Modulus(number1, number2);
                        Console.WriteLine("Result is: " + res);
                        break;
                }


            }
        }
    }
}
