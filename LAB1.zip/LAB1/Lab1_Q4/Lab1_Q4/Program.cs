﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            int rollNumber;
                string studentName, address;
                byte age;
                char gender;
                DateTime dob;
                float percentage;
            Student obj ;
            Console.WriteLine("Enter number of students");
            int n = Convert.ToInt32(Console.ReadLine());

            Student[] arr = new Student[n];
            for (int i = 0; i< n; i++)
            {
                arr[i] = new Student();
                Console.WriteLine("Enter Details");
                Console.WriteLine("Enter Roll number");
                rollNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter name");
                studentName = Console.ReadLine();
                Console.WriteLine("Enter address");
                address = Console.ReadLine();
                Console.WriteLine("Enter age");
                age = Convert.ToByte(Console.ReadLine());
                Console.WriteLine("Enter gender");
                gender = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("Enter date of birth");
                dob = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Percentage");
                percentage = float.Parse(Console.ReadLine());
                arr[i].studentDetails(rollNumber, studentName,address, age, gender, dob, percentage);
            }

            for(int index = 0; index < n; index++)
            {
                arr[index].display();
            }
        }
    }
}
