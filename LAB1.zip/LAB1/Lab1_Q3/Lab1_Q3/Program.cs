﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ENter ur choice");
            int choice = Convert.ToInt32(args[0]);
            switch (choice){
                    case 1: Console.WriteLine("Hi You have selected option 1");
                    break;

                case 2:
                    Console.WriteLine("Hi You have selected option 2");
                    break;

                case 3:
                    Console.WriteLine("Hi You have selected option 3");
                    break;

                case 4:
                    Console.WriteLine("Hi You have selected option 4");
                    break;

                case 5:
                    Console.WriteLine("Hi You have selected option 5");
                    break;

                case 6:
                    Console.WriteLine("Hi You have selected option 6");
                    break;

                case 7:
                    Console.WriteLine("Hi You have selected option 7");
                    break;
                default:
                    Console.WriteLine("Hi You have wrong selected ");
                    break;

            }
        }
    }
}
